print('python-3.6 OK')
