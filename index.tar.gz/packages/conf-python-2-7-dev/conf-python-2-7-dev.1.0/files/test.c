#include "python2.7/Python.h"

int main() {
  return 0;
}
